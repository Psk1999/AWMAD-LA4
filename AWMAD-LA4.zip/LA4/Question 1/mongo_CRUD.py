import pymongo 
import os
import pandas as pd
import sys
import io
import json
from pymongo import MongoClient
from bson.objectid import ObjectId
from pymongo import mongo_client

connection_url = "mongodb://localhost:27017/?readPreference=primary&appname=MongoDB%20Compass&ssl=false"
client = MongoClient(host=connection_url)
print(client.list_database_names())
client['Languages']['language'].insert_one({
    "_id":"3",
    "name":"Hacked",
    "age":222,
    "language":["python3"]
})
new = {
    "_id":"6",
    "name":"Purva Kudre",
    "age":222,
    "language":["python3"]
}
client['Languages']['language'].find_one_and_update({"_id":"2"},{"$set":new})





